<?php

$data = 
    array(
        array(
            'id' => '1',
            'name' => 'A Event Name',
            'chapter' => 'B Chapter Name',
            'serviceDate' => '2012-01-01 13:00:00',
            'charity' => 'D Charity Name',
            'hours' => '10',
            'raised' => '$100.00',
            'status' => 'New'
        ),
        array(
            'id' => '2',
            'name' => 'Event B Name',
            'chapter' => 'A Chapter B Name',
            'serviceDate' => '2013-01-01 13:00:00',
            'charity' => 'Charity B Name',
            'hours' => '20',
            'raised' => '$200.00',
            'status' => 'New'
        ),
        array(
            'id' => '3',
            'name' => 'Event C Name',
            'chapter' => 'D Chapter C Name',
            'serviceDate' => '2014-01-01 13:00:00',
            'charity' => 'Charity C Name',
            'hours' => '30',
            'raised' => '$300.00',
            'status' => 'Aprpoved'
        )
    );
    

// parse the request URI to find the requested record if (if exists)
$id = substr($_SERVER['REQUEST_URI'], strrpos($_SERVER['REQUEST_URI'], '/') + 1);

// if there was an id provided, and it's valid, display just that record
if( is_numeric($id) && isset($data[$id-1]) )
    echo json_encode($data[$id-1]);

// else display all the records
else
    echo json_encode($data);
