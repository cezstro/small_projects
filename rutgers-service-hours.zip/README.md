# Service Hours Listing

A lightweight Backbone.js application designed for the Rutgers University Office of Fraternity and Sorority Affairs Portal.

The application uses backbone.js to query a dataset from a given server asynchronusly using backbone.fetch() and display the data using underscores.js templating engine.
The application also allows the user to sort the displayed data in ascending and descending order with some minor UI enhancements provided by jQuery.

## Authors
* Raheem Hardy
* Mike Abdallah
