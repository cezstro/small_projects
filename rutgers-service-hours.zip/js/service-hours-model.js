/**
 * Service Hours Model
 * 
 * Defines the "ServiceHours" model, and sets the applicable default values.
 */
var ServiceHoursModel = Backbone.Model.extend({

	defaults: {
		name: 'Event Name',
		chapter: 'Student Life',
		serviceDate: '0000-00-00 00:00:00',
		charity: 'Charity',
		hours: 0,
		raised: '$0.00',
		status: 'submitted'
	}
});
