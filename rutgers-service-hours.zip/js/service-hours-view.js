/**
 * Service Hours View
 *
 * Defines the view/template for an individual record.
 */
var ServiceHoursView = Backbone.View.extend({

	tagName: 'tr',

	className: 'service-hours',

	template: $('#serviceHoursTemplate').html(),

	initialize: function() {
		this.model.bind('change', this.render, this);
		this.model.fetch();
	},

	render: function() {
		var tmpl = _.template(this.template), records = this.model.toJSON();

		this.$el.html(tmpl(records));
		return this;
	}
});

/**
 * Service Hours Filtered
 *
 * Defines the master view/template for the entire application.
 */
var ServiceHoursFiltered = Backbone.View.extend({
	el: $("tbody"),

	initialize: function() {
		var self = this;

		self.collection = new ServiceHoursCollection(serviceHours);

		/*self.collection.fetch({
			success: function() {
				// render after fully loaded
				self.render();
			}
		});*/
	},

	render: function() {
		var self = this, records = this.collection.models, selected = $('th[data-filter="' + this.collection._order_by + '"]');

		// clear the post container
		self.$el.html('');

		// loop over collection and render records
		_.each(records, function(item) {
			self.renderRecord(item);
		}, this);

		$('th > i').removeClass('icon-chevron-down');
		$('th > i').removeClass('icon-chevron-up');

		if(this.collection._sort === 'asc') {
			$(selected).find('i').addClass('icon-chevron-up');
		} else {
			$(selected).find('i').addClass('icon-chevron-down');
		}
	},

	renderRecord: function(item) {
		var recordView = new ServiceHoursView({
			model: item
		});

		this.$el.append(recordView.render().el);
	}
});
