/**
 * Service Hours Router
 * 
 * Allows backbone to change filtering options based on the url provided in the browser.
 *
 */
var ServiceHoursRouter = Backbone.Router.extend({

	routes: {
		":filter": "urlFilter",
		"*param": "noFilter"
	},

	urlFilter: function(filter) {
		filtered.collection.set_filter(filter);
		filtered.render();
	},

	noFilter: function(param) {
		filtered.render();
	}
}); 