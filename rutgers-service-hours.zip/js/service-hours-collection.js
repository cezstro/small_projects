/**
 * Service Hours Collection
 * 
 * Integrates the backbone model, router and associated views.
 */
var ServiceHoursCollection = Backbone.Collection.extend({

	model: ServiceHoursModel,

	url: '/backbone/json.php',

	comparator: function(record) {
		var output;

		if(this._sort == 'asc') {

			switch(this._order_by) {
				case "event-name":
					output = record.get('name');
					break;
				case "chapter-name":
					output = record.get('chapter');
					break;
				case "date":
					output = record.get('serviceDate');
					break;
				case "charity":
					output = record.get('charity');
					break;
				case "hours":
					output = record.get('hours');
					break;
				case "amount-raised":
					output = record.get('raised');
					break;
				case "status":
					output = record.get('status');
					break;
			}

		} else {

			switch(this._order_by) {
				case "event-name":
					output = this._sort_alphabetically(record.get('name'));
					break;
				case "chapter-name":
					output = this._sort_alphabetically(record.get('chapter'));
					break;
				case "date":
					output = -record.get('serviceDate');
					break;
				case "charity":
					output = this._sort_alphabetically(record.get('charity'));
					break;
				case "hours":
					output = -record.get('hours');
					break;
				case "amount-raised":
					output = -record.get('raised');
					break;
				case "status":
					output = this._sort_alphabetically(record.get('status'));
					break;
			}

		}

		return output;
	},

	set_filter: function(filter, sort) {

		if(sort !== undefined) {
			this._sort = sort;
		}

		this._order_by = filter;
		this.sort();
	},

	_order_by: 'date',

	_sort: 'asc',

	_sort_alphabetically: function(model) {
		model = model.toLowerCase();
		model = model.split("");
		model = _.map(model, function(letter) {
		    return String.fromCharCode(-(letter.charCodeAt(0)));
		});

		return model;
	}
});
